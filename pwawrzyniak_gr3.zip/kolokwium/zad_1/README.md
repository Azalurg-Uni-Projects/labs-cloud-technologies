# Zadanie 1
- `docker build -f Dockerfile.server .`
- `docker run -p 5000:5000 f79ef5dd20cc `
- `docker build -f Dockerfile.alpine .`
- `docker run 5b51c62f0b2b` 
- `docker run -it alpine`