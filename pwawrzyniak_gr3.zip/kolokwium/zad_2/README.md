# Zadanie 2

- `docker compose up --build`